// button to bring up a popup
function reward(){
	$('.reward').show();
}
function login(){
	$('.login').show();
}
function facebook(){
	$('.facebook').show();
}
function twitter(){
	$('.twitter').show();
}
function google(){
	$('.google').show();
}
// button to close the popup
function closelogin(){
	$(".login").hide()
}
function closefb(){
	$('.facebook').hide();
}
function closetwit(){
	$('.twitter').hide();
}
function closegog(){
	$('.google').hide();
}